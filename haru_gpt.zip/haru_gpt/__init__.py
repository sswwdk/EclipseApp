"""
Haru GPT API - 대화형 활동 추천 시스템
"""

__version__ = "1.0.0"

